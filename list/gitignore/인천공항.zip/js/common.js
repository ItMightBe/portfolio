
// 각 section height 뷰포트 높이로 맞추기	
$(document).ready(	function() {
    var viewPortHeight;
    var firstViewPortHeight;
    var sec = document.getElementsByTagName("section");

    window.addEventListener('resize', redraw);
    firstRedraw();

    function firstRedraw () {
        firstViewPortHeight = window.innerHeight;
        for(var i = 0; i < sec.length; i++ ) {
            sec[i].style.height = firstViewPortHeight + "px";
        }
    }
    function redraw () {
        viewPortHeight = window.innerHeight;
        for(var i = 0; i < sec.length; i++ ) {
            sec[i].style.height = viewPortHeight + "px";
        }
    }
})

